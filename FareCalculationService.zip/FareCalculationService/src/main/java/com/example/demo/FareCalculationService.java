package com.example.demo;

import org.springframework.stereotype.Service;

@Service
public class FareCalculationService {
	
	 public double calculateFare(String pickupLocation, String dropLocation, String typeOfCab) {
	        // Implement actual fare calculation logic here
	        double baseFare;
	        switch (typeOfCab.toLowerCase()) {
	            case "sedan":
	                baseFare = 150.0;
	                break;
	            case "suv":
	                baseFare = 200.0;
	                break;
	            case "hatchback":
	                baseFare = 100.0;
	                break;
	            default:
	                baseFare = 120.0;
	                break;
	        }
	        // Mock distance calculation between locations
	        double distance = 10.0; // example fixed distance
	        return baseFare + (distance * 10); // fare calculation logic
	    }
	}
