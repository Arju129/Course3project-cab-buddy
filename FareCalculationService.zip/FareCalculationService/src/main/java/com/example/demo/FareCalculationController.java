package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/fare")
public class FareCalculationController {

	@Autowired
	private FareCalculationService fareCalculationService;
	
	 @PostMapping("/calculate")
	    public double calculateFare(@RequestParam String pickupLocation, @RequestParam String dropLocation,@RequestParam String typeOfCab) {
	        return fareCalculationService.calculateFare(pickupLocation, dropLocation, typeOfCab);
	    }
}
