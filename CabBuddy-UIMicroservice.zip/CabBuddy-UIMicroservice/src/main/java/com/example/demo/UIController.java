package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class UIController {
	
	@Autowired
    private BookingClient bookingClient;

    @Autowired
    private FareClient fareClient;
    
    @GetMapping("/")
    public String index() {
        return "index";
    }

    @GetMapping("/bookCab")
    public String bookCabForm() {
        return "booking";
    }

    @PostMapping("/bookCab")
    public String bookCab(@RequestParam String pickupLocation, @RequestParam String dropLocation,@RequestParam String typeOfCab, Model model) {
        double fare = fareClient.calculateFare(pickupLocation, dropLocation,typeOfCab);
        String confirmation = bookingClient.bookCab(pickupLocation, dropLocation,typeOfCab, fare);
        model.addAttribute("confirmation", confirmation);
        return "confirmation";
    }

    @GetMapping("/calculateFare")
    public String calculateFareForm() {
        return "fare";
    }

    @PostMapping("/calculateFare")
    public String calculateFare(@RequestParam String pickupLocation, @RequestParam String dropLocation, @RequestParam String typeOfCab, Model model) {
        double fare = fareClient.calculateFare(pickupLocation, dropLocation,typeOfCab);
        model.addAttribute("fare", fare);
        return "fareResult";
    }
}

	


