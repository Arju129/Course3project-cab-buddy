package com.example.demo;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "booking-service", url = "http://localhost:8081")
public interface BookingClient {

	@PostMapping("/api/bookings/book")
    String bookCab(@RequestParam String pickupLocation, @RequestParam String dropLocation, @RequestParam String typeOfCab, @RequestParam Double fare);
}
