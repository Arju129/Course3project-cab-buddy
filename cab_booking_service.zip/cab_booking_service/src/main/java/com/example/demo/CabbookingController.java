package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/bookings")
public class CabbookingController {

	@Autowired
	private CabbookingService cabbookingservice;
	
	@PostMapping("/book")
    public Cabbooking bookCab(
            @RequestParam String pickupLocation,
            @RequestParam String dropLocation,
            @RequestParam String typeOfCab,
            @RequestParam Double fare) {
        return cabbookingservice.bookCab(pickupLocation, dropLocation, fare, typeOfCab);
    }
}
