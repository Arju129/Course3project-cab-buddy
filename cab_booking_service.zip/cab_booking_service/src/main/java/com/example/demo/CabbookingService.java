package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CabbookingService {

	@Autowired
	private CabbookingRepository cabbookingRepository;
	
	public Cabbooking bookCab(String pickupLocation, String dropLocation, Double fare, String typeOfCab) {
		Cabbooking cabBooking = new Cabbooking();
        cabBooking.setPickupLocation(pickupLocation);
        cabBooking.setDropLocation(dropLocation);
        cabBooking.setFare(fare);
        cabBooking.setTypeOfCab(typeOfCab);
        return cabbookingRepository.save(cabBooking);
    }
}
