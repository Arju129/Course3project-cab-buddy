package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CabbookingRepository extends JpaRepository<Cabbooking, Long> {
    // No additional methods needed if using basic CRUD operations
}